# M5 Forecasting & Dynamic Pricing Dashboard

Complete end-to-end solution for demand forecasting and dynamic pricing optimization using deep learning.

## Status: ✅ READY TO USE

**Dashboard URL:** http://localhost:8504

---

## 📦 Available Store Data

### Included: 1 Store (GitHub-Ready)
- `merged_CA_1.pkl` (181 MB) - California Store 1

**Why only 1 store?**
- ✅ GitHub-friendly (avoids 25MB file warnings)
- ✅ Fast download and deployment
- ✅ Fully functional demo
- ✅ Users can generate 9 more stores locally

### Generate Additional Stores Locally

To add the remaining 9 stores:

```bash
python generate_remaining_stores.py
```

This creates:
- CA_2, CA_3, CA_4 (California)
- TX_1, TX_2, TX_3 (Texas)
- WI_1, WI_2, WI_3 (Wisconsin)

**Total:** 10 stores × 5.9M rows each

---

## 🚀 Quick Start

### Option 1: Run Locally
```bash
# Clone repository (if from GitHub)
git clone https://github.com/YOUR_USERNAME/m5-forecasting-dashboard.git
cd m5-forecasting-dashboard

# Install dependencies
pip install -r requirements.txt

# Run dashboard
streamlit run app.py
```

### Option 2: Already Have Files
1. **Open Dashboard:**
   ```
   http://localhost:8504
   ```

2. **Select Store:**
   - Use the dropdown in the sidebar (starts with CA_1)

3. **Configure Parameters (Optional):**
   - **Base Price Elasticity:** -1.5 (default)
   - **Min Elasticity:** -0.2 (default)
   - **Price Floor Ratio:** 0.8 (default)

4. **Run Pipeline:**
   - Click the "Run Pipeline" button
   - Wait for the analysis to complete

5. **View Results:**
   - Revenue comparison charts
   - Top 10 items by revenue
   - Download CSV reports

---

## 📊 Dashboard Features

### Demand Forecasting
- **GRU Neural Network** trained on 100K samples
- **Lag Features:** 7, 14, 28 days
- **Rolling Averages:** 7, 28 days
- **Validation RMSE:** ~3.5

### Dynamic Pricing
- **Price Elasticity Model**
- **Adaptive Pricing Strategy:**
  - High-demand items: Full price adjustment range (-15% to +15%)
  - Low-demand items: Conservative adjustments (0% to +10%)
- **Price Floor Protection:** Minimum 80% of current price

### Analytics
- **Revenue Impact Analysis**
- **Price Distribution Charts**
- **Item-Level Recommendations**
- **CSV Export Capabilities**

---

## 📁 Project Structure

```
m5-forecasting-accuracy/
├── app.py                           # Main Streamlit dashboard
├── generate_data_and_model.py       # Initial data generation script
├── generate_remaining_stores.py     # Script to process remaining stores
├── requirements.txt                 # Python dependencies
├── README.md                        # This file
│
├── models/
│   └── gru_model.keras             # Trained GRU model (126 KB)
│
├── processed/
│   ├── merged_CA_1.pkl             # California store 1
│   ├── merged_CA_2.pkl             # California store 2
│   ├── merged_CA_3.pkl             # California store 3
│   ├── merged_CA_4.pkl             # California store 4
│   ├── merged_TX_1.pkl             # Texas store 1
│   ├── merged_TX_2.pkl             # Texas store 2
│   ├── merged_TX_3.pkl             # Texas store 3
│   ├── merged_WI_1.pkl             # Wisconsin store 1
│   ├── merged_WI_2.pkl             # Wisconsin store 2
│   └── merged_WI_3.pkl             # Wisconsin store 3
│
└── [M5 Data Files]
    ├── sales_train_evaluation.csv
    ├── calendar.csv
    └── sell_prices.csv
```

---

## 🔧 Technical Details

### Model Architecture
```
GRU Model
├── GRU Layer (50 units)
├── Dropout (0.2)
└── Dense Layer (1 unit)

Total Parameters: 8,601
Training: 20 epochs, batch size 32
Optimizer: Adam
Loss: Mean Squared Error
```

### Data Processing
- **Memory Optimization:** 85% reduction in memory usage
- **Feature Engineering:** Automatic lag and rolling features
- **Data Types:** Optimized int8/int16/float32
- **Missing Values:** Synthetic price imputation

### Performance
- **Prediction Speed:** ~3-5 seconds per store
- **Full Pipeline:** ~30-60 seconds per store
- **Memory Efficient:** Handles 5.9M rows per store

---

## 💻 Commands

### Start Dashboard
```bash
"/c/Users/Admin/AppData/Local/Microsoft/WindowsApps/PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0/python.exe" -m streamlit run app.py
```

### Regenerate All Store Data
```bash
"/c/Users/Admin/AppData/Local/Microsoft/WindowsApps/PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0/python.exe" generate_data_and_model.py
```

### Generate Missing Stores Only
```bash
"/c/Users/Admin/AppData/Local/Microsoft/WindowsApps/PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0/python.exe" generate_remaining_stores.py
```

---

## 📈 Example Results

### Revenue Impact (Typical)
- **Store:** CA_1
- **Total Actual Revenue:** $15,107,433.81
- **Total Estimated Revenue:** $15,988,804.10
- **Revenue Increase:** +$881,370.30 (+5.83%)

### Price Adjustments
- **Average Price Change:** +2.5% to +7%
- **Items with Increases:** ~60-70%
- **Items with Decreases:** ~10-15%
- **Items Unchanged:** ~15-30%

---

## 🎯 Use Cases

1. **Retail Pricing Strategy**
   - Optimize prices across all stores
   - Maximize revenue while maintaining competitiveness

2. **Demand Forecasting**
   - Predict future sales trends
   - Improve inventory management

3. **Store Comparison**
   - Compare performance across locations
   - Identify best-performing stores/items

4. **What-If Analysis**
   - Test different elasticity assumptions
   - Simulate pricing scenarios

---

## 🛠️ Customization

### Adjust Elasticity Model
Edit `app.py` lines 163-167:
```python
DEFAULT_ELASTICITY = -1.5
DEFAULT_MIN_ELASTICITY = -0.2
DEFAULT_PRICE_FLOOR = 0.8
PRICE_ADJUSTMENTS_FULL = [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15]
```

### Retrain Model
Edit `generate_data_and_model.py`:
- Adjust epochs (line 213): `epochs=50`
- Change batch size (line 214): `batch_size=64`
- Modify GRU units (line 202): `units=100`

---

## 📊 Data Sources

- **M5 Competition Data** (Kaggle)
- **Time Period:** 2011-2016
- **Products:** 3,049 items
- **Categories:** FOODS, HOBBIES, HOUSEHOLD
- **Observations per Store:** 5.9M

---

## 🎓 Methodology

### Forecasting Approach
1. **Time Series Features:**
   - Lag features (7, 14, 28 days)
   - Rolling means (7, 28 days)

2. **Deep Learning:**
   - GRU (Gated Recurrent Unit)
   - Sequence modeling
   - Temporal pattern recognition

### Pricing Optimization
1. **Price Elasticity:**
   - Demand = f(price, elasticity)
   - Adaptive elasticity by demand level

2. **Revenue Maximization:**
   - Test multiple price points
   - Select optimal price per item
   - Subject to price floor constraints

---

## ⚡ Performance Tips

1. **Faster Processing:**
   - Use fewer items (adjust in app.py)
   - Reduce epochs for quick testing
   - Cache results for repeated analysis

2. **Memory Optimization:**
   - Process one store at a time
   - Close unused browser tabs
   - Clear cache periodically

---

## 📝 Notes

- **Model Training:** One-time ~10 minutes for initial setup
- **Data Generation:** ~15 minutes for all 10 stores
- **Dashboard Response:** Real-time for navigation, 30-60s for pipeline
- **Browser:** Chrome/Firefox/Edge recommended

---

## 🎉 Ready to Use!

Open your browser and navigate to:
### **http://localhost:8504**

Select any of the **10 stores** and start optimizing prices!

---

## 📞 Support

For questions or issues with the dashboard:
1. Check that all 10 `.pkl` files exist in `processed/`
2. Verify `gru_model.keras` exists in `models/`
3. Ensure TensorFlow is installed
4. Restart the Streamlit server if needed

---

**Built with:** Python 3.11 | TensorFlow 2.20 | Streamlit 1.50 | Pandas | NumPy | Plotly
