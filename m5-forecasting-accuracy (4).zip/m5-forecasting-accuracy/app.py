"""
M5 Forecasting & Dynamic Pricing Dashboard
===========================================
A Streamlit application for demand forecasting and dynamic pricing optimization
using GRU deep learning model.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path
import gc
import os
import warnings
warnings.filterwarnings("ignore")

# TensorFlow imports
try:
    from tensorflow.keras.models import load_model
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False
    st.error("TensorFlow is not installed. Please install it to use this app.")

# ====================
# Configuration
# ====================
DATA_DIR = Path("data/merged")
MODEL_DIR = Path("models")
PROCESSED_DIR = Path("processed")

# Pricing parameters
DEFAULT_ELASTICITY = -1.5
DEFAULT_MIN_ELASTICITY = -0.2
DEFAULT_PRICE_FLOOR = 0.8
PRICE_ADJUSTMENTS_FULL = [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15]
PRICE_ADJUSTMENTS_LIMITED = [0, 0.05, 0.10]

# ====================
# Caching Functions
# ====================

@st.cache_data
def load_merged_data(file_path):
    """Load merged pickle data with caching."""
    try:
        df = pd.read_pickle(file_path)
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

@st.cache_resource
def load_gru_model(model_path):
    """Load GRU model with caching."""
    if not TENSORFLOW_AVAILABLE:
        return None
    try:
        model = load_model(str(model_path))
        return model
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None

# ====================
# Feature Engineering
# ====================

def create_lag_features(df, lags=[7, 14, 28], rolling_windows=[7, 28]):
    """Create lag and rolling window features for time series."""
    st.info("Creating lag and rolling features...")

    # Ensure d_num exists
    if "d_num" not in df.columns:
        df["d_num"] = df["d"].str[2:].astype(int)

    # Sort by id and d_num
    df = df.sort_values(["id", "d_num"]).reset_index(drop=True)

    # Group by item id
    grouped = df.groupby("id", observed=False)

    # Create lag features
    for lag in lags:
        df[f"sales_lag{lag}"] = grouped["sales"].shift(lag)

    # Create rolling mean features
    for w in rolling_windows:
        df[f"sales_rollmean{w}"] = grouped["sales"].shift(1).rolling(w, min_periods=1).mean()

    # Fill missing values
    feature_cols = [f"sales_lag{x}" for x in lags] + [f"sales_rollmean{x}" for x in rolling_windows]
    df[feature_cols] = df[feature_cols].fillna(0)

    return df, feature_cols

# ====================
# Demand Forecasting
# ====================

def predict_demand(df, model, feature_cols):
    """Predict demand using GRU model."""
    st.info("Predicting demand with GRU model...")

    # Reshape data for GRU input (samples, time steps, features)
    X_predict = df[feature_cols].values.reshape((df.shape[0], 1, len(feature_cols)))

    # Predict
    with st.spinner("Running GRU predictions..."):
        predicted_demand = model.predict(X_predict, verbose=0)

    df["predicted_demand_raw"] = predicted_demand.flatten()

    # Scale predictions to historical average
    item_avg_sales = df.groupby("id")["sales"].mean()
    item_predicted_avg = df.groupby("id")["predicted_demand_raw"].mean()

    # Calculate scaling factor
    scaling_factor = (item_avg_sales / item_predicted_avg).replace([np.inf, -np.inf], np.nan).fillna(1.0)

    # Apply scaling
    df["predicted_demand"] = df.apply(
        lambda row: max(row["predicted_demand_raw"] * scaling_factor.get(row["id"], 1.0), 0),
        axis=1
    )

    return df

# ====================
# Price Handling
# ====================

def handle_missing_prices(df):
    """Fill missing or zero sell prices with item averages."""
    st.info("Handling missing prices...")

    item_avg_prices = df.groupby("id")["sell_price"].mean()

    def fill_synthetic_price(row):
        if pd.isna(row["sell_price"]) or row["sell_price"] <= 0:
            base_price = item_avg_prices.get(row["id"], 1.0)
            return base_price
        return row["sell_price"]

    df["sell_price"] = df.apply(fill_synthetic_price, axis=1)
    return df

# ====================
# Dynamic Pricing
# ====================

def calculate_adjusted_demand(current_price, predicted_demand, candidate_price, elasticity):
    """Calculate demand adjusted for price change using elasticity."""
    if current_price <= 0:
        return predicted_demand
    return predicted_demand * ((candidate_price / current_price) ** elasticity)

def optimize_pricing(df, base_elasticity, min_elasticity, price_floor_ratio):
    """Optimize pricing for all items in the dataset."""
    st.info("Optimizing prices...")

    optimal_prices = []

    progress_bar = st.progress(0)
    total_rows = len(df)

    for idx, (index, row) in enumerate(df.iterrows()):
        current_price = row["sell_price"]
        predicted_demand = row["predicted_demand"]

        # Choose price adjustment range based on demand
        if predicted_demand < 0.5:
            price_adjustments = PRICE_ADJUSTMENTS_LIMITED
            elasticity = min_elasticity
        else:
            price_adjustments = PRICE_ADJUSTMENTS_FULL
            elasticity = base_elasticity

        best_revenue = -np.inf
        optimal_price = current_price

        # Test each price adjustment
        for adjustment in price_adjustments:
            candidate_price = current_price * (1 + adjustment)
            candidate_price = max(candidate_price, current_price * price_floor_ratio)

            adjusted_demand = calculate_adjusted_demand(
                current_price, predicted_demand, candidate_price, elasticity
            )
            adjusted_demand = max(adjusted_demand, 0)
            expected_revenue = adjusted_demand * candidate_price

            if expected_revenue > best_revenue:
                best_revenue = expected_revenue
                optimal_price = candidate_price

        optimal_prices.append({
            "id": row["id"],
            "item_id": row["item_id"],
            "date": row["date"],
            "current_price": current_price,
            "predicted_demand": predicted_demand,
            "optimized_price": optimal_price,
            "optimized_revenue": best_revenue
        })

        # Update progress every 1000 rows
        if idx % 1000 == 0:
            progress_bar.progress(min(idx / total_rows, 1.0))

    progress_bar.progress(1.0)

    return pd.DataFrame(optimal_prices)

# ====================
# Revenue Analysis
# ====================

def calculate_revenue_impact(df, df_optimal):
    """Calculate revenue impact of dynamic pricing."""
    # Merge optimal prices with original data
    df_eval = pd.merge(
        df,
        df_optimal,
        on=["id", "date", "predicted_demand"],
        how="left"
    )

    # Calculate actual historical revenue
    df_eval["actual_revenue"] = df_eval["sales"] * df_eval["sell_price"]

    # Calculate totals
    total_actual = df_eval["actual_revenue"].sum()
    total_estimated = df_eval["optimized_revenue"].sum()
    revenue_change = total_estimated - total_actual
    revenue_change_pct = (revenue_change / total_actual * 100) if total_actual > 0 else 0

    return {
        "total_actual": total_actual,
        "total_estimated": total_estimated,
        "revenue_change": revenue_change,
        "revenue_change_pct": revenue_change_pct,
        "df_eval": df_eval
    }

# ====================
# Visualization
# ====================

def plot_revenue_comparison(actual, estimated, store_id):
    """Create bar chart comparing actual vs estimated revenue."""
    fig = go.Figure(data=[
        go.Bar(
            x=["Actual Historical Revenue", "Estimated Revenue (Dynamic Pricing)"],
            y=[actual, estimated],
            marker_color=["#1f77b4", "#ff7f0e"],
            text=[f"${actual:,.0f}", f"${estimated:,.0f}"],
            textposition="auto",
        )
    ])

    fig.update_layout(
        title=f"Revenue Comparison - {store_id}",
        yaxis_title="Total Revenue ($)",
        height=500,
        showlegend=False
    )

    return fig

def plot_price_distribution(df_optimal):
    """Plot distribution of price changes."""
    df_optimal["price_change_pct"] = (
        (df_optimal["optimized_price"] - df_optimal["current_price"]) / df_optimal["current_price"] * 100
    )

    fig = px.histogram(
        df_optimal,
        x="price_change_pct",
        nbins=50,
        title="Distribution of Price Changes",
        labels={"price_change_pct": "Price Change (%)"}
    )

    fig.update_layout(height=400)
    return fig

# ====================
# Main App
# ====================

def main():
    st.set_page_config(
        page_title="M5 Forecasting & Dynamic Pricing",
        page_icon="📊",
        layout="wide"
    )

    st.title("📊 M5 Forecasting & Dynamic Pricing Dashboard")
    st.markdown("---")

    # Sidebar
    st.sidebar.header("⚙️ Configuration")

    # Check for available data files
    merged_files = []

    # Check multiple possible locations
    possible_dirs = [DATA_DIR, PROCESSED_DIR, Path(".")]

    for directory in possible_dirs:
        if directory.exists():
            merged_files.extend(list(directory.glob("merged_*.pkl")))

    if not merged_files:
        st.error("❌ No merged data files found!")
        st.info("""
        **Expected file locations:**
        - `data/merged/merged_*.pkl`
        - `processed/merged_*.pkl`
        - Root directory: `merged_*.pkl`

        Please ensure merged data files exist before running the app.
        """)
        return

    # File selection
    file_names = [f.name for f in merged_files]
    selected_file_name = st.sidebar.selectbox(
        "📁 Select Store Data",
        file_names
    )

    # Extract store ID from filename
    try:
        store_id = selected_file_name.split("_")[1].split(".")[0]
    except:
        store_id = "Unknown"

    st.sidebar.info(f"**Store ID:** {store_id}")

    # Pricing parameters
    st.sidebar.subheader("💰 Pricing Parameters")

    elasticity = st.sidebar.slider(
        "Base Price Elasticity",
        min_value=-3.0,
        max_value=-0.1,
        value=DEFAULT_ELASTICITY,
        step=0.1,
        help="How much demand changes with price (negative value)"
    )

    min_elasticity = st.sidebar.slider(
        "Min Elasticity (Low Demand)",
        min_value=-1.0,
        max_value=-0.1,
        value=DEFAULT_MIN_ELASTICITY,
        step=0.1,
        help="Elasticity for low-demand items"
    )

    price_floor = st.sidebar.slider(
        "Price Floor Ratio",
        min_value=0.5,
        max_value=1.0,
        value=DEFAULT_PRICE_FLOOR,
        step=0.05,
        help="Minimum price as ratio of current price"
    )

    # Model file selection
    model_files = list(MODEL_DIR.glob("*.h5")) + list(MODEL_DIR.glob("*.keras"))
    model_files_root = list(Path(".").glob("*.h5")) + list(Path(".").glob("*.keras"))
    model_files.extend(model_files_root)

    if not model_files:
        st.sidebar.error("❌ No model files found!")
        st.error("""
        **Model file not found!**

        Please ensure the GRU model file exists:
        - `models/gru_model.h5` or `models/gru_model.keras`
        - Or in the root directory
        """)
        return

    model_file = model_files[0]
    st.sidebar.success(f"✅ Model: {model_file.name}")

    # Run button
    run_pipeline = st.sidebar.button("🚀 Run Pipeline", type="primary")

    # Main content
    if run_pipeline:
        st.header(f"Running Pipeline for Store: **{store_id}**")

        # Find the full path to selected file
        selected_file_path = None
        for f in merged_files:
            if f.name == selected_file_name:
                selected_file_path = f
                break

        if selected_file_path is None:
            st.error("Could not find selected file!")
            return

        # Step 1: Load data
        with st.spinner("Loading data..."):
            df = load_merged_data(selected_file_path)

        if df is None:
            return

        st.success(f"✅ Data loaded: {df.shape[0]:,} rows, {df.shape[1]} columns")

        # Step 2: Load model
        with st.spinner("Loading GRU model..."):
            model = load_gru_model(model_file)

        if model is None:
            return

        st.success("✅ Model loaded successfully")

        # Step 3: Feature engineering
        df, feature_cols = create_lag_features(df)
        st.success(f"✅ Features created: {len(feature_cols)} features")

        # Step 4: Predict demand
        df = predict_demand(df, model, feature_cols)
        st.success("✅ Demand predictions complete")

        # Step 5: Handle prices
        df = handle_missing_prices(df)
        st.success("✅ Prices processed")

        # Step 6: Optimize pricing
        df_optimal = optimize_pricing(df, elasticity, min_elasticity, price_floor)
        st.success("✅ Price optimization complete")

        # Step 7: Calculate revenue impact
        results = calculate_revenue_impact(df, df_optimal)

        st.markdown("---")
        st.header("📈 Results")

        # Display metrics
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric(
                "Actual Revenue",
                f"${results['total_actual']:,.0f}"
            )

        with col2:
            st.metric(
                "Estimated Revenue",
                f"${results['total_estimated']:,.0f}"
            )

        with col3:
            st.metric(
                "Revenue Change",
                f"${results['revenue_change']:,.0f}",
                delta=f"{results['revenue_change_pct']:.2f}%"
            )

        with col4:
            st.metric(
                "Change %",
                f"{results['revenue_change_pct']:.2f}%"
            )

        # Revenue comparison chart
        st.subheader("Revenue Comparison")
        fig = plot_revenue_comparison(
            results['total_actual'],
            results['total_estimated'],
            store_id
        )
        st.plotly_chart(fig, use_container_width=True)

        # Price change distribution
        col1, col2 = st.columns(2)

        with col1:
            st.subheader("Price Change Distribution")
            fig = plot_price_distribution(df_optimal)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            st.subheader("Summary Statistics")
            avg_price_change = ((df_optimal["optimized_price"] - df_optimal["current_price"]) / df_optimal["current_price"] * 100).mean()

            st.write(f"**Average Price Change:** {avg_price_change:.2f}%")
            st.write(f"**Total Items:** {df_optimal['item_id'].nunique():,}")
            st.write(f"**Total Observations:** {len(df_optimal):,}")

        # Top items by revenue gain
        st.subheader("🏆 Top 10 Items by Optimized Revenue")

        # Aggregate by item
        item_summary = df_optimal.groupby("item_id").agg({
            "current_price": "mean",
            "optimized_price": "mean",
            "predicted_demand": "sum",
            "optimized_revenue": "sum"
        }).reset_index()

        top_items = item_summary.nlargest(10, "optimized_revenue")

        # Format for display
        display_df = top_items.copy()
        display_df["current_price"] = display_df["current_price"].apply(lambda x: f"${x:.2f}")
        display_df["optimized_price"] = display_df["optimized_price"].apply(lambda x: f"${x:.2f}")
        display_df["predicted_demand"] = display_df["predicted_demand"].apply(lambda x: f"{x:.0f}")
        display_df["optimized_revenue"] = display_df["optimized_revenue"].apply(lambda x: f"${x:,.2f}")

        st.dataframe(display_df, use_container_width=True)

        # Download button
        csv = top_items.to_csv(index=False)
        st.download_button(
            label="📥 Download Top Items CSV",
            data=csv,
            file_name=f"top_items_{store_id}.csv",
            mime="text/csv"
        )

        # Full results download
        st.subheader("📊 Full Results")
        full_csv = df_optimal.to_csv(index=False)
        st.download_button(
            label="📥 Download Full Results CSV",
            data=full_csv,
            file_name=f"full_results_{store_id}.csv",
            mime="text/csv"
        )

        # Cleanup
        del df, df_optimal, results
        gc.collect()

    else:
        # Show instructions
        st.info("""
        ### 📋 Instructions

        1. **Select a store** from the sidebar dropdown
        2. **Adjust pricing parameters** (optional):
           - Base Price Elasticity: How demand responds to price changes
           - Min Elasticity: Elasticity for low-demand items
           - Price Floor Ratio: Minimum allowed price
        3. **Click "Run Pipeline"** to start the analysis

        The pipeline will:
        - Load store data
        - Create time-series features
        - Predict demand using the GRU model
        - Optimize prices to maximize revenue
        - Display results and comparisons
        """)

        # Show available files
        st.subheader("📁 Available Data Files")
        st.write([f.name for f in merged_files])

if __name__ == "__main__":
    main()
