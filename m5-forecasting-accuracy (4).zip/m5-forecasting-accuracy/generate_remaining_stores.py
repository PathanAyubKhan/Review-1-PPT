"""
Generate remaining store data files (CA_4, TX_1, TX_2, TX_3, WI_1, WI_2, WI_3)
"""

import os
import gc
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

print("="*70)
print("Generating Remaining Store Data Files")
print("="*70)

# Memory Reduction Function
def reduce_memory_usage(df):
    start_mem = df.memory_usage().sum() / 1024**2
    print(f"  Memory usage: {start_mem:.2f} MB -> ", end="")

    for col in df.columns:
        col_type = df[col].dtype

        if col_type not in [object, 'category']:
            df[col] = df[col].fillna(0)
            c_min = df[col].min()
            c_max = df[col].max()

            if str(col_type).startswith('int'):
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                else:
                    df[col] = df[col].astype(np.int64)
            else:
                df[col] = df[col].astype(np.float32)
        else:
            if col_type == object and df[col].nunique() / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')

    end_mem = df.memory_usage().sum() / 1024**2
    print(f"{end_mem:.2f} MB (reduced by {(start_mem - end_mem)/start_mem*100:.1f}%)")
    return df

OUTPUT_DIR = "processed"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load datasets
print("\nLoading datasets...")
sales_eval = pd.read_csv("sales_train_evaluation.csv")
calendar = pd.read_csv("calendar.csv")
sell_prices = pd.read_csv("sell_prices.csv")
print("[OK] Datasets loaded")

# Get all stores
all_stores = sales_eval["store_id"].unique()

# Check which stores already exist
existing_stores = []
for store in all_stores:
    if os.path.exists(os.path.join(OUTPUT_DIR, f"merged_{store}.pkl")):
        existing_stores.append(store)

# Find stores that need to be processed
stores_to_process = [s for s in all_stores if s not in existing_stores]

print(f"\nExisting stores ({len(existing_stores)}): {existing_stores}")
print(f"Stores to process ({len(stores_to_process)}): {stores_to_process}")

if not stores_to_process:
    print("\n[OK] All stores already processed!")
    exit(0)

# Process remaining stores
for store in stores_to_process:
    print(f"\n{'='*70}")
    print(f"Processing store: {store}")
    print(f"{'='*70}")

    # Filter for this store
    df_store = sales_eval[sales_eval["store_id"] == store].copy()
    df_store = reduce_memory_usage(df_store)

    # Melt the subset
    fixed_cols = ["id", "item_id", "dept_id", "cat_id", "store_id", "state_id"]
    date_cols = [c for c in df_store.columns if c.startswith("d_")]

    print("  Melting data...")
    df_melted_sub = pd.melt(
        df_store,
        id_vars=fixed_cols,
        value_vars=date_cols,
        var_name="d",
        value_name="sales"
    )
    del df_store
    gc.collect()

    # Merge with calendar
    print("  Merging with calendar...")
    df_cal_sub = pd.merge(df_melted_sub, calendar, how="left", on="d")
    del df_melted_sub
    gc.collect()

    # Filter sell_prices for this store
    print("  Merging with prices...")
    sp_sub = sell_prices[sell_prices["store_id"] == store].copy()
    sp_sub = reduce_memory_usage(sp_sub)

    df_merged_sub = pd.merge(
        df_cal_sub,
        sp_sub,
        how="left",
        on=["store_id", "item_id", "wm_yr_wk"]
    )
    del df_cal_sub, sp_sub
    gc.collect()

    df_merged_sub = reduce_memory_usage(df_merged_sub)

    # Save to disk
    out_path = os.path.join(OUTPUT_DIR, f"merged_{store}.pkl")
    df_merged_sub.to_pickle(out_path)
    print(f"  [OK] Saved: {out_path} (shape: {df_merged_sub.shape})")

    del df_merged_sub
    gc.collect()

print("\n" + "="*70)
print(f"[OK] All {len(stores_to_process)} remaining stores processed!")
print("="*70)

# List all store files
all_files = sorted([f for f in os.listdir(OUTPUT_DIR) if f.startswith("merged_")])
print(f"\nTotal store files available: {len(all_files)}")
for f in all_files:
    print(f"  - {f}")
