# 🚀 GitHub Deployment Guide - M5 Forecasting Dashboard

Complete guide for deploying to GitHub and Streamlit Cloud (with 25MB file size limit workaround).

---

## 🎯 Challenge: GitHub 25MB File Size Limit

GitHub has a **25MB file size warning** and **100MB hard limit**.

**Our Solution:**
- ✅ Keep only **1 store** (CA_1) in the repository
- ✅ Total project size: **~200 MB** (within limits)
- ✅ Users can generate additional stores locally if needed

---

## 📦 What's Included in GitHub Repository

### Core Files (Lightweight)
```
✅ app.py                          18 KB
✅ requirements.txt                114 bytes
✅ generate_data_and_model.py      7.7 KB
✅ generate_remaining_stores.py    4.2 KB
✅ README.md                       7.3 KB
✅ SETUP_GUIDE.md                  12 KB
✅ QUICK_START.txt                 5.8 KB
✅ GITHUB_DEPLOYMENT.md            (this file)
✅ .gitignore                      (to exclude large files)
```

### Model File (Small)
```
✅ models/gru_model.keras          127 KB
```

### Data File (1 Store Only)
```
✅ processed/merged_CA_1.pkl       181 MB   (California Store 1)
```

### Raw CSV Files: NOT INCLUDED
```
❌ calendar.csv                    (Users download from Kaggle if needed)
❌ sales_train_evaluation.csv     (Users download from Kaggle if needed)
❌ sell_prices.csv                 (Users download from Kaggle if needed)
```

**Why excluded?**
- CSV files are only needed to regenerate `.pkl` files
- The `.pkl` file already contains all processed data
- Saves 426 MB of repository size
- Users can download from Kaggle if they want to generate more stores

**Total Repository Size: ~182 MB** (GitHub-friendly!)

---

## 🚀 Step-by-Step GitHub Deployment

### Step 1: Create .gitignore File

Create `.gitignore` to exclude unnecessary files:

```bash
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
*.egg-info/
dist/
build/

# Jupyter Notebook
.ipynb_checkpoints
*.ipynb

# Large data files (exclude extra stores)
processed/merged_CA_2.pkl
processed/merged_CA_3.pkl
processed/merged_CA_4.pkl
processed/merged_TX_*.pkl
processed/merged_WI_*.pkl

# Exclude raw CSV files (users can download from Kaggle)
sales_train_validation.csv

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# Streamlit
.streamlit/secrets.toml
```

---

### Step 2: Initialize Git Repository

```bash
# Navigate to project folder
cd m5-forecasting-accuracy

# Initialize git
git init

# Add all files (respecting .gitignore)
git add .

# Create first commit
git commit -m "Initial commit: M5 Forecasting Dashboard with 1 store"
```

---

### Step 3: Create GitHub Repository

1. **Go to GitHub:** https://github.com
2. **Click** "New repository"
3. **Repository name:** `m5-forecasting-dashboard`
4. **Description:** "M5 Forecasting & Dynamic Pricing Dashboard using GRU Neural Network"
5. **Public/Private:** Choose based on preference
6. **Don't** initialize with README (we already have one)
7. **Click** "Create repository"

---

### Step 4: Push to GitHub

```bash
# Add remote origin (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/m5-forecasting-dashboard.git

# Push to GitHub
git branch -M main
git push -u origin main
```

⏱️ **Upload Time:** 5-10 minutes (depends on internet speed)

---

### Step 5: Verify Upload

Check on GitHub:
- ✅ All files visible
- ✅ `processed/merged_CA_1.pkl` uploaded (181 MB)
- ✅ `models/gru_model.keras` uploaded
- ✅ No warning about file sizes

---

## 🌐 Deploy to Streamlit Cloud

### Step 1: Prepare Repository

Ensure you have:
- ✅ `requirements.txt` in root directory
- ✅ `app.py` in root directory
- ✅ All necessary files committed

---

### Step 2: Sign Up for Streamlit Cloud

1. **Go to:** https://streamlit.io/cloud
2. **Sign up** with GitHub account
3. **Authorize** Streamlit to access your repositories

---

### Step 3: Deploy App

1. **Click** "New app"
2. **Select repository:** `YOUR_USERNAME/m5-forecasting-dashboard`
3. **Branch:** `main`
4. **Main file path:** `app.py`
5. **Click** "Deploy!"

⏱️ **Deployment Time:** 5-10 minutes

---

### Step 4: Access Your App

Once deployed, you'll get a URL like:
```
https://YOUR_USERNAME-m5-forecasting-dashboard-app-abc123.streamlit.app
```

Share this URL with anyone!

---

## 📝 Update README for GitHub

Add this section to your `README.md`:

```markdown
## 🚀 Quick Start

### Option 1: Run Locally
git clone https://github.com/YOUR_USERNAME/m5-forecasting-dashboard.git
cd m5-forecasting-dashboard
pip install -r requirements.txt
streamlit run app.py
```

### Option 2: Live Demo
Visit: [https://your-app-url.streamlit.app](https://your-app-url.streamlit.app)

## 📊 Available Data

This repository includes **1 pre-processed store** (CA_1) for quick testing.

To generate additional stores:
```bash
python generate_remaining_stores.py
```

This will create 9 more stores (CA_2, CA_3, CA_4, TX_1-3, WI_1-3).
```

---

## 🔧 Handling Multiple Stores Locally

Users who clone your repository can generate additional stores:

### Method 1: Generate All Stores at Once
```bash
python generate_data_and_model.py
```
This regenerates all 10 stores (~15-20 minutes).

### Method 2: Generate Specific Stores
Edit `generate_remaining_stores.py` to specify which stores:

```python
# Only generate these stores
stores_to_process = ['CA_2', 'TX_1', 'WI_1']
```

Then run:
```bash
python generate_remaining_stores.py
```

---

## 📊 File Size Breakdown

### What's in the Repository (200 MB)
```
Core application files:      50 KB
Model file:                  127 KB
Documentation:               50 KB
1 Store data file:           181 MB
Helper scripts:              12 KB
-----------------------------------------
Total:                       ~200 MB ✅
```

### What's Excluded (1.6 GB)
```
9 additional stores:         1.6 GB
Raw CSV files (optional):    426 MB
-----------------------------------------
Total excluded:              ~2.0 GB
```

---

## 🎯 Why Only 1 Store?

### Advantages:
✅ **Fast deployment** - Smaller repository
✅ **No GitHub warnings** - Under 25MB file limit per file (181MB is allowed but not recommended for all 10)
✅ **Quick cloning** - Users can clone quickly
✅ **Demo ready** - Fully functional with 1 store
✅ **Scalable** - Users generate more stores as needed

### User Experience:
- **Immediate use** with 1 store (CA_1)
- **Optional expansion** - Generate 9 more stores locally if needed
- **No performance impact** - Dashboard works identically with 1 or 10 stores

---

## 🔄 Alternative: Git LFS (Git Large File Storage)

If you want to include all 10 stores, use Git LFS:

### Install Git LFS
```bash
# Install Git LFS
git lfs install

# Track .pkl files
git lfs track "*.pkl"

# Add .gitattributes
git add .gitattributes

# Commit and push
git add .
git commit -m "Add LFS support"
git push
```

⚠️ **Note:** Git LFS has storage/bandwidth limits on free tier:
- **1 GB** storage free
- **1 GB** bandwidth per month

With 10 stores (1.8 GB), you'll exceed the free tier.

---

## 📱 Mobile-Friendly Deployment

Streamlit Cloud apps are automatically mobile-friendly!

Users can access from:
- 📱 Mobile browsers
- 💻 Desktop browsers
- 📟 Tablets

---

## 🔒 Privacy & Security

### Public Repository
- ✅ Anyone can view code
- ✅ Anyone can clone and run locally
- ✅ Great for portfolio/demos

### Private Repository
- 🔒 Only you and collaborators can access
- 🔒 Streamlit Cloud supports private repos
- 🔒 Good for proprietary work

### Security Best Practices
- ❌ **Never** commit API keys or passwords
- ❌ **Never** commit `.env` files with secrets
- ✅ Use Streamlit secrets for sensitive data
- ✅ Add sensitive files to `.gitignore`

---

## 📈 Monitoring Your App

### Streamlit Cloud Dashboard
- View app logs
- See resource usage (CPU, memory)
- Monitor uptime
- View visitor analytics

### App Settings
- Set custom subdomain
- Configure Python version
- Set secrets (for API keys)
- Manage collaborators

---

## 🛠️ Updating Your Deployed App

Any push to `main` branch automatically redeploys:

```bash
# Make changes to code
vim app.py

# Commit changes
git add app.py
git commit -m "Update pricing algorithm"

# Push to GitHub
git push origin main
```

Streamlit Cloud detects the push and redeploys automatically (1-2 minutes).

---

## 🧪 Testing Before Deployment

Always test locally before pushing:

```bash
# Test app locally
streamlit run app.py

# Test with different stores
# Verify all features work
# Check for errors in terminal

# If everything works, commit and push
git add .
git commit -m "Tested and ready"
git push
```

---

## 📊 Repository Structure (GitHub-Ready)

```
m5-forecasting-dashboard/          (Repository name)
│
├── .gitignore                      (Exclude large files)
├── app.py                          (Main app)
├── requirements.txt                (Dependencies)
├── README.md                       (Project overview)
├── SETUP_GUIDE.md                  (Setup instructions)
├── GITHUB_DEPLOYMENT.md            (This file)
│
├── models/
│   └── gru_model.keras            (Trained model)
│
├── processed/
│   └── merged_CA_1.pkl            (1 store only - 181 MB)
│
└── [Optional - in .gitignore]
    ├── generate_data_and_model.py  (For local generation)
    ├── calendar.csv                (Download from Kaggle)
    ├── sales_train_evaluation.csv  (Download from Kaggle)
    └── sell_prices.csv             (Download from Kaggle)
```

---

## ✅ Deployment Checklist

### Before Pushing to GitHub:
```
□ Created .gitignore file
□ Removed extra store files (keep only CA_1)
□ Verified file sizes (all under 200 MB total)
□ Tested app locally
□ Updated README.md
□ Committed all changes
```

### GitHub Upload:
```
□ Created GitHub repository
□ Added remote origin
□ Pushed to main branch
□ Verified files on GitHub
□ Checked no warnings about file sizes
```

### Streamlit Cloud Deployment:
```
□ Signed up for Streamlit Cloud
□ Connected GitHub account
□ Selected repository
□ Deployed app
□ Tested live URL
□ Shared with users
```

---

## 🎉 You're Live!

Once deployed, your dashboard is:
- ✅ **Accessible worldwide** via URL
- ✅ **Automatically updated** on git push
- ✅ **Mobile-friendly** and responsive
- ✅ **Free to host** on Streamlit Cloud
- ✅ **Professional** portfolio piece

---

## 📞 Support

**Streamlit Cloud Issues:**
- Docs: https://docs.streamlit.io/streamlit-community-cloud
- Forum: https://discuss.streamlit.io

**GitHub Issues:**
- Docs: https://docs.github.com
- Support: https://support.github.com

---

**Ready to deploy! Follow these steps and your app will be live in 15-20 minutes!** 🚀
