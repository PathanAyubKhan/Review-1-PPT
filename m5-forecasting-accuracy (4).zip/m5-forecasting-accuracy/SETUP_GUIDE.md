# 🚀 M5 Forecasting Dashboard - Setup Guide for New Laptop

Complete step-by-step guide to run this project on any new computer.

---

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [File Transfer](#file-transfer)
3. [Installation Steps](#installation-steps)
4. [Running the Dashboard](#running-the-dashboard)
5. [Troubleshooting](#troubleshooting)

---

## 1️⃣ Prerequisites

### Required Software

#### **Python 3.11 (Recommended)**
- **Download:** https://www.python.org/downloads/
- **During Installation:**
  - ✅ Check "Add Python to PATH"
  - ✅ Check "Install pip"
  - Choose "Customize installation"
  - ✅ Install for all users (optional)

#### **Git (Optional - for version control)**
- **Download:** https://git-scm.com/downloads

### System Requirements
- **OS:** Windows 10/11, macOS, or Linux
- **RAM:** Minimum 8GB (16GB recommended)
- **Storage:** At least 5GB free space
- **Internet:** Required for initial setup only

---

## 2️⃣ File Transfer

### Option A: Copy All Files (Recommended)

**Copy the entire project folder** to your new laptop:

```
m5-forecasting-accuracy/
├── app.py
├── generate_data_and_model.py
├── generate_remaining_stores.py
├── requirements.txt
├── README.md
├── SETUP_GUIDE.md (this file)
├── .gitignore
│
├── models/
│   └── gru_model.keras
│
└── processed/
    └── merged_CA_1.pkl            (1 store only - 181 MB)
```

**Total Size:** ~182 MB

**Note:** This includes only 1 store (CA_1). You can generate 9 more stores locally if needed.

### Transfer Methods:
- **USB Drive:** Copy entire folder
- **Cloud Storage:** Google Drive, OneDrive, Dropbox
- **Network Transfer:** Shared folder or FTP
- **Git:** Clone repository (if using version control)

---

### Option B: Regenerate All Stores from Scratch

If you want all 10 stores but don't have them:

1. **Copy Option A files** (182 MB)
2. **Download M5 CSV files** from Kaggle:
   - Go to: https://www.kaggle.com/c/m5-forecasting-accuracy/data
   - Download: `calendar.csv`, `sales_train_evaluation.csv`, `sell_prices.csv`
   - Place in project root folder

3. **Regenerate all stores:**
   ```bash
   python generate_data_and_model.py
   ```
   This creates all 10 stores (~15-20 minutes).

---

## 3️⃣ Installation Steps

### Step 1: Verify Python Installation

Open **Command Prompt** (Windows) or **Terminal** (Mac/Linux) and run:

```bash
python --version
```

**Expected Output:** `Python 3.11.x` (or 3.9+)

**If not found:**
- Windows: Add Python to PATH in System Environment Variables
- Mac/Linux: Use `python3` instead of `python`

### Step 2: Navigate to Project Directory

```bash
cd path/to/m5-forecasting-accuracy
```

**Example:**
- Windows: `cd C:\Users\YourName\Documents\m5-forecasting-accuracy`
- Mac/Linux: `cd ~/Documents/m5-forecasting-accuracy`

**Verify you're in the right folder:**
```bash
dir         # Windows
ls          # Mac/Linux
```

You should see `app.py`, `requirements.txt`, etc.

---

### Step 3a: Install Python Dependencies

#### **Windows:**
```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

#### **Mac/Linux:**
```bash
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
```

**This will install:**
- streamlit
- pandas
- numpy
- tensorflow
- plotly
- scikit-learn
- joblib

⏱️ **Installation Time:** 5-15 minutes (depending on internet speed)

**Note:** TensorFlow download is ~330 MB, so be patient!

---

### Step 3b: Verify Installation

```bash
python -c "import streamlit; print('Streamlit:', streamlit.__version__)"
python -c "import tensorflow; print('TensorFlow:', tensorflow.__version__)"
```

**Expected Output:**
```
Streamlit: 1.50.0
TensorFlow: 2.20.0
```

---

### Step 3c: Generate Additional Stores (Optional)

**The repository includes 1 store (CA_1).** If you want 9 more stores:

1. **Download M5 CSV files from Kaggle:**
   - https://www.kaggle.com/c/m5-forecasting-accuracy/data
   - Download: `calendar.csv`, `sales_train_evaluation.csv`, `sell_prices.csv`
   - Place in project root

2. **Generate remaining stores:**
   ```bash
   python generate_remaining_stores.py
   ```

⏱️ **Processing Time:** ~15-20 minutes

**This creates:**
- `processed/merged_CA_2.pkl` through `merged_WI_3.pkl` (9 additional stores)

**Progress Output:**
```
======================================================================
M5 Forecasting - Data Generation & Model Training Script
======================================================================

STEP 1: Creating Merged Data Files
Processing all 10 stores: ['CA_1', 'CA_2', ...]

Processing store: CA_1
  Memory usage: 45.31 MB -> 6.52 MB (reduced by 85.6%)
  [OK] Saved: processed\merged_CA_1.pkl

...

STEP 2: Training GRU Model
Training GRU model (this may take a few minutes)...
Epoch 1/20
...
[OK] Model saved: models/gru_model.keras

[OK] ALL DONE!
```

---

## 4️⃣ Running the Dashboard

### Step 1: Start Streamlit

#### **Windows:**
```bash
python -m streamlit run app.py
```

#### **Mac/Linux:**
```bash
python3 -m streamlit run app.py
```

### Step 2: Access Dashboard

The terminal will display:
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501
```

**Open your browser and go to:** `http://localhost:8501`

**Troubleshooting Port Issues:**
If port 8501 is busy, Streamlit will use 8502, 8503, etc. Check the terminal output for the correct port.

---

### Step 3: Use the Dashboard

1. **Select Store:** Choose from dropdown (CA_1, CA_2, ..., WI_3)
2. **Adjust Parameters** (optional):
   - Base Price Elasticity: -1.5
   - Min Elasticity: -0.2
   - Price Floor Ratio: 0.8
3. **Click "Run Pipeline"**
4. **Wait 30-60 seconds** for processing
5. **View Results:**
   - Revenue comparison charts
   - Top 10 items
   - Download CSV

---

### Step 4: Stop the Dashboard

Press `Ctrl + C` in the terminal to stop the Streamlit server.

---

## 5️⃣ Troubleshooting

### ❌ Problem: "Python not found"

**Solution:**
- Reinstall Python and check "Add to PATH"
- Or use full path: `C:\Users\YourName\AppData\Local\Programs\Python\Python311\python.exe`

---

### ❌ Problem: "No module named 'streamlit'"

**Solution:**
```bash
python -m pip install streamlit
```

If still not working:
```bash
python -m pip install --user streamlit
```

---

### ❌ Problem: "No merged data files found"

**Solution:**

**Check if files exist:**
```bash
dir processed        # Windows
ls processed/        # Mac/Linux
```

**You should see at least `merged_CA_1.pkl`**

**If missing:**
1. Verify you copied the `processed/` folder
2. Check if CA_1 store file is present
3. If generating more stores, download CSV files from Kaggle first:
   ```bash
   python generate_remaining_stores.py
   ```

---

### ❌ Problem: "TensorFlow installation failed"

**Solution:**

**Try installing specific version:**
```bash
python -m pip install tensorflow==2.17.0
```

**For Mac with M1/M2 chip:**
```bash
python -m pip install tensorflow-macos
python -m pip install tensorflow-metal
```

**For older CPUs (no AVX):**
Use TensorFlow 2.9.0 or earlier

---

### ❌ Problem: "Port already in use"

**Solution:**

Streamlit automatically tries next available port. Check terminal for actual port:
```
Local URL: http://localhost:8502  # Note: 8502 instead of 8501
```

Or manually specify port:
```bash
python -m streamlit run app.py --server.port 8505
```

---

### ❌ Problem: "Dashboard is very slow"

**Solutions:**

1. **Reduce processing load** - Edit `app.py` and reduce sample size
2. **Close other programs** - Free up RAM
3. **Use fewer stores** - Focus on 1-2 stores at a time
4. **Check CPU usage** - Task Manager / Activity Monitor

---

### ❌ Problem: "Out of Memory"

**Solution:**

Your computer may not have enough RAM. Try:

1. **Process one store at a time**
2. **Close browser tabs**
3. **Restart computer**
4. **Reduce training epochs** (edit `generate_data_and_model.py`)

---

## 6️⃣ Quick Start Checklist

Use this checklist when setting up on a new laptop:

```
□ Install Python 3.11
□ Copy project folder to new laptop (182 MB)
□ Open terminal/command prompt
□ Navigate to project directory (cd ...)
□ Run: pip install -r requirements.txt
□ Verify: python -c "import streamlit"
□ Check files: dir processed/ (should see merged_CA_1.pkl)
□ (Optional) Generate more stores if needed
□ Start dashboard: python -m streamlit run app.py
□ Open browser: http://localhost:8501
□ Select CA_1 store and click "Run Pipeline"
□ Success! 🎉
```

---

## 7️⃣ Alternative: Virtual Environment (Recommended)

For cleaner Python package management:

### Windows:
```bash
# Create virtual environment
python -m venv venv

# Activate it
venv\Scripts\activate

# Install packages
pip install -r requirements.txt

# Run dashboard
python -m streamlit run app.py

# Deactivate when done
deactivate
```

### Mac/Linux:
```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate

# Install packages
pip install -r requirements.txt

# Run dashboard
python -m streamlit run app.py

# Deactivate when done
deactivate
```

---

## 8️⃣ Cloud Deployment (Optional)

### Streamlit Cloud (Free)

1. **Upload to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Deploy to Streamlit Cloud:**
   - Go to https://share.streamlit.io
   - Connect GitHub repository
   - Select `app.py`
   - Click "Deploy"

**Note:** You'll need to upload the processed `.pkl` files using Git LFS or regenerate them on deployment.

---

## 9️⃣ Generating Additional Stores

### Default: 1 Store Included (CA_1)
The project includes 1 pre-processed store for immediate use.

### Want More Stores?

**Step 1: Download M5 Data from Kaggle**
1. Go to: https://www.kaggle.com/c/m5-forecasting-accuracy/data
2. Sign in to Kaggle
3. Download these files:
   - `calendar.csv` (102 KB)
   - `sales_train_evaluation.csv` (117 MB)
   - `sell_prices.csv` (194 MB)
4. Place them in your project root directory

**Step 2: Generate Stores**
```bash
# Generate 9 additional stores (CA_2, CA_3, CA_4, TX_1-3, WI_1-3)
python generate_remaining_stores.py
```

⏱️ **Time:** 15-20 minutes
📦 **Output:** 9 new `.pkl` files (~1.6 GB total)

### Why Only 1 Store by Default?
- ✅ GitHub-friendly (182 MB vs 2 GB)
- ✅ Fast download and setup
- ✅ Fully functional for testing
- ✅ Users generate more stores as needed

---

## 🔟 System-Specific Notes

### Windows 11
- Works out of the box
- Use PowerShell or Command Prompt
- May need to allow Python through firewall

### macOS (Intel)
- Use `python3` instead of `python`
- Use `pip3` instead of `pip`
- May need to install Xcode Command Line Tools

### macOS (M1/M2)
- Install Rosetta 2 if needed
- Use `tensorflow-macos` instead of `tensorflow`
- Performance is excellent

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install python3-pip python3-venv
pip3 install -r requirements.txt
python3 -m streamlit run app.py
```

---

## 🆘 Still Having Issues?

### Diagnostic Commands

Run these to help diagnose problems:

```bash
# Check Python version
python --version

# Check pip version
python -m pip --version

# List installed packages
python -m pip list

# Check if files exist
dir                    # Windows
ls -la                 # Mac/Linux

# Test imports
python -c "import streamlit; import tensorflow; import pandas; print('All imports OK')"
```

### Common Error Messages

| Error | Cause | Fix |
|-------|-------|-----|
| `ModuleNotFoundError` | Package not installed | `pip install package_name` |
| `FileNotFoundError` | Missing data files | Run `generate_data_and_model.py` |
| `Permission denied` | No write access | Run as administrator or change folder |
| `Address already in use` | Port conflict | Use different port with `--server.port` |
| `Out of memory` | Insufficient RAM | Close other programs |

---

## 📞 Contact & Support

If you encounter any issues not covered here:

1. **Check logs:** Look at terminal output for error messages
2. **Verify files:** Ensure all required files are present
3. **Test step-by-step:** Run each command individually
4. **Check versions:** Ensure Python 3.9+ and compatible packages

---

## ✅ Success Criteria

You'll know everything is working when:

✅ Dashboard opens in browser at http://localhost:8501
✅ All 10 stores appear in dropdown
✅ "Run Pipeline" button works
✅ Charts and results display correctly
✅ CSV downloads work

---

## 📚 Useful Resources

- **Streamlit Docs:** https://docs.streamlit.io
- **TensorFlow Guide:** https://www.tensorflow.org/install
- **Python Installation:** https://www.python.org/downloads/
- **M5 Competition:** https://www.kaggle.com/c/m5-forecasting-accuracy

---

## 🎉 You're All Set!

Once you complete these steps, your dashboard will be running on the new laptop with full access to all 10 stores and dynamic pricing functionality.

**Estimated Setup Time:**
- 15-20 minutes (with 1 store - default)
- 30-45 minutes (if generating all 10 stores)

---

**Happy Forecasting! 📊**
