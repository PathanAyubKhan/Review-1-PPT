# 📦 Files to Transfer to New Laptop

Complete list of files needed to run the M5 Forecasting Dashboard on a new computer.

---

## 🎯 Two Transfer Options

### **Option A: Complete Transfer (Recommended)**
✅ **Fastest setup** - Just copy and run
⚠️ **Large size** - ~2.3 GB total
⏱️ **Setup time** - 20-30 minutes

### **Option B: Minimal Transfer + Regenerate**
✅ **Smaller transfer** - ~426 MB
⚠️ **Longer setup** - Need to regenerate data
⏱️ **Setup time** - 45-60 minutes

---

## 📋 Option A: Complete Transfer (2.3 GB)

Copy the **entire project folder** with all files:

### Core Application Files (38 KB)
```
✅ app.py                          18 KB    (Main dashboard)
✅ requirements.txt                114 bytes (Dependencies)
✅ README.md                       7.3 KB   (Documentation)
✅ SETUP_GUIDE.md                  12 KB    (Setup instructions)
✅ QUICK_START.txt                 5.8 KB   (Quick reference)
✅ FILES_TO_TRANSFER.md            (This file)
```

### Helper Scripts (12 KB)
```
✅ generate_data_and_model.py      7.7 KB   (Data generation script)
✅ generate_remaining_stores.py    4.2 KB   (Additional stores script)
```

### Model Files (254 KB)
```
✅ models/gru_model.keras          127 KB   (Trained GRU model)
✅ gru_model.keras                 127 KB   (Model backup - root)
```

### Processed Store Data (1.8 GB) - LARGE FILES
```
✅ processed/merged_CA_1.pkl       181 MB   (California store 1)
✅ processed/merged_CA_2.pkl       181 MB   (California store 2)
✅ processed/merged_CA_3.pkl       181 MB   (California store 3)
✅ processed/merged_CA_4.pkl       181 MB   (California store 4)
✅ processed/merged_TX_1.pkl       181 MB   (Texas store 1)
✅ processed/merged_TX_2.pkl       181 MB   (Texas store 2)
✅ processed/merged_TX_3.pkl       181 MB   (Texas store 3)
✅ processed/merged_WI_1.pkl       181 MB   (Wisconsin store 1)
✅ processed/merged_WI_2.pkl       181 MB   (Wisconsin store 2)
✅ processed/merged_WI_3.pkl       181 MB   (Wisconsin store 3)
```

### Optional: Raw M5 Data (426 MB)
```
⚠️ calendar.csv                    102 KB   (Only if regenerating)
⚠️ sales_train_evaluation.csv     117 MB   (Only if regenerating)
⚠️ sales_train_validation.csv     115 MB   (Not needed)
⚠️ sell_prices.csv                 194 MB   (Only if regenerating)
```

**Total Size: ~2.3 GB** (without raw CSV files) or **~2.7 GB** (with raw files)

---

## 📋 Option B: Minimal Transfer (426 MB + regenerate)

Copy only these files, then regenerate processed data on new laptop:

### Essential Files (38 KB)
```
✅ app.py                          18 KB
✅ requirements.txt                114 bytes
✅ generate_data_and_model.py      7.7 KB
✅ SETUP_GUIDE.md                  12 KB
✅ QUICK_START.txt                 5.8 KB
```

### Raw M5 Data (426 MB) - REQUIRED for regeneration
```
✅ calendar.csv                    102 KB
✅ sales_train_evaluation.csv     117 MB
✅ sell_prices.csv                 194 MB
```

**Total Size: 426 MB**

**Then on new laptop, run:**
```bash
python generate_data_and_model.py
```
This will create all 10 `.pkl` files and the model (~15-20 minutes).

---

## 📁 Required Folder Structure

Make sure to maintain this structure:

```
m5-forecasting-accuracy/          (Main folder)
│
├── app.py
├── requirements.txt
├── generate_data_and_model.py
├── generate_remaining_stores.py
├── README.md
├── SETUP_GUIDE.md
├── QUICK_START.txt
├── FILES_TO_TRANSFER.md
│
├── models/                        (Create if not exists)
│   └── gru_model.keras
│
├── processed/                     (Create if not exists)
│   ├── merged_CA_1.pkl
│   ├── merged_CA_2.pkl
│   ├── merged_CA_3.pkl
│   ├── merged_CA_4.pkl
│   ├── merged_TX_1.pkl
│   ├── merged_TX_2.pkl
│   ├── merged_TX_3.pkl
│   ├── merged_WI_1.pkl
│   ├── merged_WI_2.pkl
│   └── merged_WI_3.pkl
│
└── [Raw M5 CSV files - optional]
    ├── calendar.csv
    ├── sales_train_evaluation.csv
    └── sell_prices.csv
```

---

## 🚀 Transfer Methods

### USB Drive / External Hard Drive
1. Copy entire `m5-forecasting-accuracy` folder
2. Paste on new laptop
3. Done!

### Cloud Storage (Google Drive, OneDrive, Dropbox)
1. **Upload folder** to cloud
2. **Share link** or sync to new laptop
3. **Download** entire folder
4. ⚠️ Large file warning: May take 30-60 minutes to upload

### Network Transfer / Shared Folder
1. **Share folder** on old laptop
2. **Access** from new laptop via network
3. **Copy** entire folder

### Git / GitHub (Advanced)
⚠️ **Not recommended for .pkl files** (too large for GitHub)

**If using Git:**
1. Use Git LFS for large files
2. Or use Option B (regenerate data)

```bash
git init
git add *.py *.md *.txt *.csv requirements.txt
git commit -m "Initial commit"
git push origin main
```

Then regenerate `.pkl` files on new laptop.

### Compression (Optional)
You can compress the folder to save space:

**Windows:** Right-click → Send to → Compressed (zipped) folder
**Mac:** Right-click → Compress
**Linux:** `tar -czf m5-project.tar.gz m5-forecasting-accuracy/`

**Compressed size:** ~1.5 GB (from 2.3 GB)

---

## ✅ Verification Checklist

After transferring files, verify everything is present:

### Check Core Files
```bash
cd m5-forecasting-accuracy
dir           # Windows
ls -la        # Mac/Linux
```

You should see:
- ✅ app.py
- ✅ requirements.txt
- ✅ SETUP_GUIDE.md
- ✅ Other documentation files

### Check Model
```bash
dir models                  # Windows
ls models/                  # Mac/Linux
```

You should see:
- ✅ gru_model.keras

### Check Store Data
```bash
dir processed               # Windows
ls processed/               # Mac/Linux
```

You should see:
- ✅ 10 `.pkl` files (merged_CA_1.pkl through merged_WI_3.pkl)

### Verify File Sizes
```bash
# Check total size
dir processed               # Windows - look for file sizes
ls -lh processed/           # Mac/Linux - shows human-readable sizes
```

Each `.pkl` file should be **~181 MB**

---

## 🔍 File Descriptions

### app.py
**Purpose:** Main Streamlit dashboard application
**Size:** 18 KB
**Required:** ✅ YES
**Contains:** UI, forecasting logic, pricing optimization

### requirements.txt
**Purpose:** Python package dependencies
**Size:** 114 bytes
**Required:** ✅ YES
**Contains:** List of packages to install (streamlit, tensorflow, pandas, etc.)

### gru_model.keras
**Purpose:** Trained GRU neural network model
**Size:** 127 KB
**Required:** ✅ YES
**Contains:** Model weights and architecture for demand forecasting

### merged_*.pkl files
**Purpose:** Pre-processed store data
**Size:** 181 MB each (1.8 GB total)
**Required:** ✅ YES (or regenerate)
**Contains:** Sales, calendar, and price data for each store

### generate_data_and_model.py
**Purpose:** Script to generate all data files and train model
**Size:** 7.7 KB
**Required:** ⚠️ Only if regenerating
**Usage:** Run once to create all `.pkl` files

### calendar.csv, sales_train_evaluation.csv, sell_prices.csv
**Purpose:** Raw M5 competition data
**Size:** 426 MB total
**Required:** ⚠️ Only if regenerating
**Source:** Kaggle M5 Forecasting Competition

---

## ⏱️ Time Estimates

### Option A (Complete Transfer)
- **Upload/Transfer Time:** 15-30 minutes (depends on method)
- **Python Setup:** 10-15 minutes
- **Verification:** 2-3 minutes
- **Total:** ~30-50 minutes

### Option B (Minimal Transfer + Regenerate)
- **Upload/Transfer Time:** 5-10 minutes
- **Python Setup:** 10-15 minutes
- **Data Generation:** 15-20 minutes
- **Total:** ~30-45 minutes (but more active work)

---

## 💾 Storage Requirements

### On Old Laptop (Current)
- **Used:** 2.7 GB

### On New Laptop
- **Option A:** 2.3 GB (without raw CSVs) or 2.7 GB (with raw CSVs)
- **Option B:** 426 MB initially, then 2.3 GB after generation

### During Transfer
- **USB Drive:** Need 3 GB free space
- **Cloud Storage:** Need 3 GB quota
- **Temporary:** May need extra space for compression

---

## 🎯 Recommended Approach

### For Most Users: Option A
✅ Transfer entire folder
✅ Fastest setup on new laptop
✅ No need to wait for data generation
✅ Immediate use after `pip install`

### For Limited Storage/Bandwidth: Option B
✅ Smaller transfer size
✅ Regenerate data on new laptop
✅ Good if you have slow internet
⚠️ Requires 15-20 minutes processing time

---

## 🚨 Don't Forget!

Before leaving your old laptop:

- ✅ **Verify all files copied** (check file count and sizes)
- ✅ **Test on new laptop** (run `python -m streamlit run app.py`)
- ✅ **Keep backup** on old laptop until confirmed working
- ✅ **Save documentation** (SETUP_GUIDE.md, QUICK_START.txt)

---

## 📞 Quick Reference

**Minimum Required Files:**
- app.py
- requirements.txt
- models/gru_model.keras
- processed/merged_*.pkl (10 files)

**Total Minimum Size:** 2.05 GB

**Commands After Transfer:**
```bash
cd m5-forecasting-accuracy
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

---

## ✅ Success Criteria

You'll know the transfer was successful when:

✅ All files present (check with `dir` or `ls`)
✅ Correct file sizes (~181 MB per .pkl file)
✅ Model file exists (gru_model.keras)
✅ Dashboard starts without errors
✅ All 10 stores visible in dropdown

---

**Ready to transfer! Choose your option and follow the steps in SETUP_GUIDE.md** 🚀
