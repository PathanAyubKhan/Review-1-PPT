"""
Generate merged data files and GRU model for the M5 Forecasting Dashboard
This script processes the raw data and trains the model needed for the Streamlit app.
"""

import os
import gc
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GRU, Dense, Dropout

print("="*70)
print("M5 Forecasting - Data Generation & Model Training Script")
print("="*70)

# =============================
# Memory Reduction Function
# =============================
def reduce_memory_usage(df):
    start_mem = df.memory_usage().sum() / 1024**2
    print(f"  Memory usage: {start_mem:.2f} MB -> ", end="")

    for col in df.columns:
        col_type = df[col].dtype

        if col_type not in [object, 'category']:
            df[col] = df[col].fillna(0)
            c_min = df[col].min()
            c_max = df[col].max()

            if str(col_type).startswith('int'):
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                else:
                    df[col] = df[col].astype(np.int64)
            else:
                df[col] = df[col].astype(np.float32)
        else:
            if col_type == object and df[col].nunique() / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')

    end_mem = df.memory_usage().sum() / 1024**2
    print(f"{end_mem:.2f} MB (reduced by {(start_mem - end_mem)/start_mem*100:.1f}%)")
    return df

# =============================
# Step 1: Create Merged Data Files
# =============================
print("\n" + "="*70)
print("STEP 1: Creating Merged Data Files")
print("="*70)

OUTPUT_DIR = "processed"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Check if files exist
if not os.path.exists("sales_train_evaluation.csv"):
    print("ERROR: sales_train_evaluation.csv not found!")
    print("Please ensure the M5 data files are in the current directory.")
    exit(1)

if not os.path.exists("calendar.csv"):
    print("ERROR: calendar.csv not found!")
    exit(1)

if not os.path.exists("sell_prices.csv"):
    print("ERROR: sell_prices.csv not found!")
    exit(1)

# Load datasets
print("\nLoading datasets...")
sales_eval = pd.read_csv("sales_train_evaluation.csv")
calendar = pd.read_csv("calendar.csv")
sell_prices = pd.read_csv("sell_prices.csv")
print("[OK] Datasets loaded successfully!")

# Process each store
all_stores = sales_eval["store_id"].unique()
print(f"\nFound {len(all_stores)} stores: {list(all_stores)}")

# Process all stores
stores_to_process = all_stores
print(f"\nProcessing all {len(stores_to_process)} stores: {list(stores_to_process)}")

for store in stores_to_process:
    print(f"\n{'='*70}")
    print(f"Processing store: {store}")
    print(f"{'='*70}")

    # Filter for this store
    df_store = sales_eval[sales_eval["store_id"] == store].copy()
    df_store = reduce_memory_usage(df_store)

    # Melt the subset
    fixed_cols = ["id", "item_id", "dept_id", "cat_id", "store_id", "state_id"]
    date_cols = [c for c in df_store.columns if c.startswith("d_")]

    print("  Melting data...")
    df_melted_sub = pd.melt(
        df_store,
        id_vars=fixed_cols,
        value_vars=date_cols,
        var_name="d",
        value_name="sales"
    )
    del df_store
    gc.collect()

    # Merge with calendar
    print("  Merging with calendar...")
    df_cal_sub = pd.merge(df_melted_sub, calendar, how="left", on="d")
    del df_melted_sub
    gc.collect()

    # Filter sell_prices for this store
    print("  Merging with prices...")
    sp_sub = sell_prices[sell_prices["store_id"] == store].copy()
    sp_sub = reduce_memory_usage(sp_sub)

    df_merged_sub = pd.merge(
        df_cal_sub,
        sp_sub,
        how="left",
        on=["store_id", "item_id", "wm_yr_wk"]
    )
    del df_cal_sub, sp_sub
    gc.collect()

    df_merged_sub = reduce_memory_usage(df_merged_sub)

    # Save to disk
    out_path = os.path.join(OUTPUT_DIR, f"merged_{store}.pkl")
    df_merged_sub.to_pickle(out_path)
    print(f"  [OK] Saved: {out_path} (shape: {df_merged_sub.shape})")

    del df_merged_sub
    gc.collect()

print("\n" + "="*70)
print("[OK] All merged data files created successfully!")
print("="*70)

# =============================
# Step 2: Train GRU Model
# =============================
print("\n" + "="*70)
print("STEP 2: Training GRU Model")
print("="*70)

# Load first store's data for training
print("\nLoading training data...")
first_store = stores_to_process[0]
df_train_data = pd.read_pickle(os.path.join(OUTPUT_DIR, f"merged_{first_store}.pkl"))
print(f"[OK] Loaded {first_store} data: {df_train_data.shape}")

# Add d_num
df_train_data["d_num"] = df_train_data["d"].str[2:].astype(int)

# Sample for faster training (use 100k rows)
print("\nSampling data for training...")
df_sample = df_train_data.sample(min(100000, len(df_train_data)), random_state=42)
df_sample = df_sample.sort_values(["id", "d_num"]).copy()
print(f"[OK] Training sample: {df_sample.shape}")

# Create lag features
print("\nCreating lag features...")
lags = [7, 14, 28]
rolling_windows = [7, 28]

grouped = df_sample.groupby("id", observed=False)

for lag in lags:
    df_sample[f"sales_lag{lag}"] = grouped["sales"].shift(lag)

for w in rolling_windows:
    df_sample[f"sales_rollmean{w}"] = grouped["sales"].shift(1).rolling(w, min_periods=1).mean()

feature_cols = [f"sales_lag{x}" for x in lags] + [f"sales_rollmean{x}" for x in rolling_windows]
df_sample[feature_cols] = df_sample[feature_cols].fillna(0)
print(f"[OK] Created {len(feature_cols)} features")

# Split train/validation
print("\nSplitting data...")
train_mask = df_sample["d_num"] < 1500
val_mask = df_sample["d_num"] >= 1500

df_train = df_sample[train_mask].copy()
df_val = df_sample[val_mask].copy()

X_train = df_train[feature_cols].values.reshape((df_train.shape[0], 1, len(feature_cols)))
y_train = df_train["sales"].values

X_val = df_val[feature_cols].values.reshape((df_val.shape[0], 1, len(feature_cols)))
y_val = df_val["sales"].values

print(f"  Train: {X_train.shape}, Validation: {X_val.shape}")

# Build GRU model
print("\nBuilding GRU model...")
model_gru = Sequential()
model_gru.add(GRU(units=50, input_shape=(X_train.shape[1], X_train.shape[2])))
model_gru.add(Dropout(0.2))
model_gru.add(Dense(units=1))
model_gru.compile(optimizer='adam', loss='mean_squared_error')

print("\nModel architecture:")
model_gru.summary()

# Train model
print("\nTraining GRU model (this may take a few minutes)...")
history = model_gru.fit(
    X_train, y_train,
    epochs=20,  # Reduced from 50 for faster training
    batch_size=32,
    validation_data=(X_val, y_val),
    verbose=1
)

# Evaluate
pred_val = model_gru.predict(X_val, verbose=0)
rmse = np.sqrt(mean_squared_error(y_val, pred_val))
print(f"\n[OK] Validation RMSE: {rmse:.4f}")

# Save model
os.makedirs("models", exist_ok=True)
model_path = "models/gru_model.keras"
model_gru.save(model_path)
print(f"[OK] Model saved: {model_path}")

# Also save in root for convenience
model_gru.save("gru_model.keras")
print(f"[OK] Model also saved: gru_model.keras")

print("\n" + "="*70)
print("[OK] ALL DONE! Files created:")
print("="*70)
print(f"  Merged data: processed/merged_*.pkl ({len(stores_to_process)} files)")
print(f"  GRU model: models/gru_model.keras")
print(f"  GRU model (root): gru_model.keras")
print("\nYou can now run the Streamlit app!")
print("="*70)
